/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body - Motor RPM Control System
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "usb_device.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "ssd1306.h"
#include "ssd1306_fonts.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

// IR Protocol Variables
volatile uint8_t inicio = 0;
volatile uint8_t flag = 0;
volatile uint8_t contador = 0;
volatile uint16_t tiempostart = 0;
volatile uint16_t tiempototal = 0;
volatile uint16_t comando = 0;
volatile uint16_t *v_decimal;

// Motor Control Variables
volatile uint8_t apagado = 1;
volatile uint8_t giro = 0;
volatile uint8_t modo = 1;

// RPM Measurement Variables
uint32_t pulse_cnt = 0;
uint32_t last_cnt = 0;
uint16_t upd_tmr = 0;
uint16_t wait_cnt = 0;

// Display Variables
float rpm_val = 0;

char disp_buf[64];
char rpm_str[32];

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

// IR Protocol Timing (in timer counts)
#define IR_BIT_0_TIME    6   // 1.2ms for bit 0
#define IR_BIT_1_TIME    9   // 1.8ms for bit 1
#define IR_TIMEOUT       50  // Timeout after command
#define RPM_UPDATE_TIME  5000 // 1 second update interval (5000 * 0.2ms = 1s)

// IR Commands
#define CMD_STOP    21  // Stop motor
#define CMD_RIGHT   18  // Rotate right
#define CMD_LEFT    9   // Rotate left

// Motor States
#define MOT_OFF     1
#define MOT_CW      2   // Clockwise
#define MOT_CCW     3   // Counter-clockwise

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
TIM_HandleTypeDef htim1;
TIM_HandleTypeDef htim3;

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
static void MX_TIM1_Init(void);
static void MX_TIM3_Init(void);

/* USER CODE BEGIN PFP */
void process_ir_cmd(void);
void update_rpm(void);
void update_display(void);
void control_motor(uint8_t state);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();
  MX_TIM3_Init();
  MX_USB_DEVICE_Init();

  /* USER CODE BEGIN 2 */
  ssd1306_Init();
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_Base_Start(&htim3);

  // Initial display
  update_display();
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    // Process IR command if ready
    if (flag == 1 && (__HAL_TIM_GET_COUNTER(&htim3) >= IR_TIMEOUT)) {
      process_ir_cmd();
      flag = 0;
      contador = 0;
      comando = 0;
      __HAL_TIM_SET_COUNTER(&htim3, 0);
    }

    // Manual wheel detection when motor off
    if (apagado == 1) {
      uint8_t pin_a8 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_8);
      uint8_t pin_a1 = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_1);

      if (pin_a8 == 0 && pin_a1 == 1) {
        modo = MOT_CCW; // Right direction
      } else if (pin_a1 == 0 && pin_a8 == 0) {
        modo = MOT_CW;  // Left direction
      }
    }

    // Update RPM calculation
    update_rpm();

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/* USER CODE BEGIN 4 */

void process_ir_cmd(void)
{
  switch(comando) {
    case CMD_STOP:
      modo = MOT_OFF;
      control_motor(0);
      apagado = 1;
      giro = 0;
      break;

    case CMD_RIGHT:
      modo = MOT_CCW;
      control_motor(1); // Right: PB3=1, PB4=0
      apagado = 0;
      giro = 1;
      break;

    case CMD_LEFT:
      modo = MOT_CW;
      control_motor(2); // Left: PB3=0, PB4=1
      apagado = 0;
      giro = 1;
      break;
  }
}

void update_rpm(void)
{
  static uint32_t last_time = 0;
  uint32_t current_time = HAL_GetTick();

  pulse_cnt = __HAL_TIM_GET_COUNTER(&htim1);

  // Actualizar cada 1000ms (1 segundo)
  if ((current_time - last_time) >= 1000) {
    uint32_t delta = pulse_cnt - last_cnt;
    // Cálculo RPM: pulsos por segundo * 60
    rpm_val = (float)(delta * 60);

    last_cnt = pulse_cnt;
    last_time = current_time;

    // Reset mode when stopped
    if (rpm_val == 0) {
      modo = MOT_OFF;
    }

    // Update display and USB transmission
    update_display();
    sprintf(rpm_str, "RPM:%.0f\r\n", rpm_val);
    CDC_Transmit_FS((uint8_t*)rpm_str, strlen(rpm_str));
  }
}

void update_display(void)
{
  // Motor status display
  if (apagado == 1) {
    switch(modo) {
      case MOT_OFF: sprintf(disp_buf, "OFF"); break;
      case MOT_CW:  sprintf(disp_buf, "OFF ->"); break;
      case MOT_CCW: sprintf(disp_buf, "OFF <-"); break;
    }
  } else {
    switch(modo) {
      case MOT_CW:  sprintf(disp_buf, "ON ->"); break;
      case MOT_CCW: sprintf(disp_buf, "ON <-"); break;
    }
  }

  sprintf(rpm_str, "RPM:%.0f", rpm_val);

  // Update OLED display
  ssd1306_Fill(Black);
  ssd1306_SetCursor(2, 0);
  ssd1306_WriteString(disp_buf, Font_11x18, White);
  ssd1306_SetCursor(2, 25);
  ssd1306_WriteString(rpm_str, Font_11x18, White);
  ssd1306_UpdateScreen();
}

void control_motor(uint8_t state)
{
  switch(state) {
    case 0: // Stop
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);
      break;
    case 1: // Right
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 1);
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 0);
      break;
    case 2: // Left
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3, 0);
      HAL_GPIO_WritePin(GPIOB, GPIO_PIN_4, 1);
      break;
  }
}

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if (GPIO_Pin == control_Pin) {
    if(flag == 1) return; // No hace nada si ya está procesando

    inicio = 1;

    if (inicio == 1 && contador == 0) {
      __HAL_TIM_SET_COUNTER(&htim3, 0); // Reinicia el contador del temporizador
      inicio = 0; // Se pone inicio a cero
      comando = 0; // Limpiar comando
      contador++; // Incrementar contador de bits
    }
    else if (contador == 1 && inicio == 1) {
      tiempostart = __HAL_TIM_GET_COUNTER(&htim3); // Estado de inicio
      contador++;
      __HAL_TIM_SET_COUNTER(&htim3, 0);
      inicio = 0;
    }
    else if (contador >= 2 && contador <= 8 && inicio == 1) {
      tiempototal = __HAL_TIM_GET_COUNTER(&htim3);

      // Decodificar bit según el tiempo del pulso
      if (tiempototal >= 5 && tiempototal <= 7) { // ~1.2 ms (tolerancia)
        // Detecta un 0 lógico
        comando = (comando << 1) | 0;
      } else if (tiempototal >= 8 && tiempototal <= 10) { // ~1.8 ms (tolerancia)
        // Detecta un 1 lógico
        comando = (comando << 1) | 1;
      }

      contador++;
      __HAL_TIM_SET_COUNTER(&htim3, 0);
      inicio = 0;

      // Si hemos recibido todos los bits
      if (contador == 9) {
        flag = 1; // Marcar que el comando está listo
        contador = 0; // Reiniciar para próximo comando
        __HAL_TIM_SET_COUNTER(&htim3, 0);
      }
    }
  }
}

/* USER CODE END 4 */

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 25;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_3) != HAL_OK)
  {
    Error_Handler();
  }
}

/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 100000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

/**
  * @brief TIM1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM1_Init(void)
{

  /* USER CODE BEGIN TIM1_Init 0 */

  /* USER CODE END TIM1_Init 0 */

  TIM_SlaveConfigTypeDef sSlaveConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM1_Init 1 */

  /* USER CODE END TIM1_Init 1 */
  htim1.Instance = TIM1;
  htim1.Init.Prescaler = 0;
  htim1.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim1.Init.Period = 65535;
  htim1.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim1.Init.RepetitionCounter = 0;
  htim1.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim1) != HAL_OK)
  {
    Error_Handler();
  }
  sSlaveConfig.SlaveMode = TIM_SLAVEMODE_EXTERNAL1;
  sSlaveConfig.InputTrigger = TIM_TS_TI1FP1;
  sSlaveConfig.TriggerPolarity = TIM_TRIGGERPOLARITY_RISING;
  sSlaveConfig.TriggerFilter = 0;
  if (HAL_TIM_SlaveConfigSynchro(&htim1, &sSlaveConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim1, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM1_Init 2 */

  /* USER CODE END TIM1_Init 2 */

}

/**
  * @brief TIM3 Initialization Function
  * @param None
  * @retval None
  */
static void MX_TIM3_Init(void)
{

  /* USER CODE BEGIN TIM3_Init 0 */

  /* USER CODE END TIM3_Init 0 */

  TIM_ClockConfigTypeDef sClockSourceConfig = {0};
  TIM_MasterConfigTypeDef sMasterConfig = {0};

  /* USER CODE BEGIN TIM3_Init 1 */

  /* USER CODE END TIM3_Init 1 */
  htim3.Instance = TIM3;
  htim3.Init.Prescaler = 0;
  htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
  htim3.Init.Period = 65535;
  htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
  htim3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
  if (HAL_TIM_Base_Init(&htim3) != HAL_OK)
  {
    Error_Handler();
  }
  sClockSourceConfig.ClockSource = TIM_CLOCKSOURCE_INTERNAL;
  if (HAL_TIM_ConfigClockSource(&htim3, &sClockSourceConfig) != HAL_OK)
  {
    Error_Handler();
  }
  sMasterConfig.MasterOutputTrigger = TIM_TRGO_RESET;
  sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
  if (HAL_TIMEx_MasterConfigSynchronization(&htim3, &sMasterConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN TIM3_Init 2 */

  /* USER CODE END TIM3_Init 2 */

}

/**
  * @brief GPIO Initialization Function
  * @param None
  * @retval None
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  /* USER CODE BEGIN MX_GPIO_Init_1 */

  /* USER CODE END MX_GPIO_Init_1 */

  /* GPIO Ports Clock Enable */
  __HAL_RCC_GPIOH_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  /*Configure GPIO pin Output Level */
  HAL_GPIO_WritePin(GPIOB, GPIO_PIN_3|GPIO_PIN_4, GPIO_PIN_RESET);

  /*Configure GPIO pin : PA1 */
  GPIO_InitStruct.Pin = GPIO_PIN_1;
  GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

  /*Configure GPIO pin : control_Pin */
  GPIO_InitStruct.Pin = control_Pin;
  GPIO_InitStruct.Mode = GPIO_MODE_IT_RISING;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(control_GPIO_Port, &GPIO_InitStruct);

  /*Configure GPIO pins : PB3 PB4 */
  GPIO_InitStruct.Pin = GPIO_PIN_3|GPIO_PIN_4;
  GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

  /* EXTI interrupt init*/
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);

  /* USER CODE BEGIN MX_GPIO_Init_2 */

  /* USER CODE END MX_GPIO_Init_2 */
}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
